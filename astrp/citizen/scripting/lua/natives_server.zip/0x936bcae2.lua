function Global.TaskEveryoneLeaveVehicle(vehicle)
	return _in(0xc1971f30, vehicle)
end
