function Global.GetEntityType(entity)
	return _in(0xb1bd08d, entity, _ri)
end
