--- Sets Ped Default Clothes
function Global.SetPedDefaultComponentVariation(ped)
	return _in(0xc866a984, ped)
end
