function Global.GetTrainCarriageEngine(train)
	return _in(0x95070fa, train, _ri)
end
