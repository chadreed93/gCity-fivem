--- setting the last params to false it does that same so I would suggest its not a toggle
function Global.RemoveAllPedWeapons(ped, p1)
	return _in(0xa44ce817, ped, p1)
end
