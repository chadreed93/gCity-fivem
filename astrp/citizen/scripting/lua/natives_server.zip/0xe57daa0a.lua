function Global.GetEntityRotationVelocity(entity)
	return _in(0x9bf8a73f, entity, _rv)
end
