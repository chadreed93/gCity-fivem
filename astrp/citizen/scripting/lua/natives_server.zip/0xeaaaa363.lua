--- A getter for [SET_RESOURCE_KVP_INT](#\_0x6A2B1E8).
-- @param key The key to fetch
-- @return A int that contains the value stored in the Kvp or nil/null if none.
function Global.GetResourceKvpInt(key)
	return _in(0x557b586a, _ts(key), _ri)
end
