function Global.GetHeliTailRotorHealth(vehicle)
	return _in(0xa41bc13d, vehicle, _rf)
end
