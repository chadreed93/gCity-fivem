--- List of component/props ID
-- gtaxscripting.blogspot.com/2016/04/gta-v-peds-component-and-props.html
function Global.SetPedRandomProps(ped)
	return _in(0xe3318e0e, ped)
end
